Lambda_func = function(n1, Gamma1, Lambda_current, F.2, Y, F, Beta, Gamma2){
   Lambda = Lambda_current
   
   for(k in 1:length(Lambda)){
     numerator = sum(Y[,k]*F) - n1*(  (Gamma1 + sum(Lambda[-k]* Gamma2[-k]))*(Gamma2[k]*(1 + sum(Beta^2))) )
     denomerator =   sum(F.2) - n1*(Gamma2[k]^2*(1 + sum(Beta^2))) 
   
     Lambda[k] = numerator/denomerator
   }
   return(Lambda)

}
