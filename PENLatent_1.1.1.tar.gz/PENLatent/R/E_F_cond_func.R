E_F_cond_func = function(n, sigma2_Y, Lambda, Y, X, Beta, Gamma1){

  Var_Fi_cond = (sum(Lambda^2/sigma2_Y) + 1)^(-1) 
  E_F_cond = rep(NA, n)

  for(ii in 1:n){
    E_F_cond[ii] =  (sum(Y[ii,]*Lambda/sigma2_Y) + Gamma1 + sum(X[ii,] * Beta) )*Var_Fi_cond
  }
  
  return(E_F_cond)
}
