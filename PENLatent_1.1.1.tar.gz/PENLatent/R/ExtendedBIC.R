ExtendedBIC <-
function(minus2ln,p,df,n){
  BIC.gamma = 1 - 1/(2*log(p)/log(n))
  tmp = 2*BIC.gamma*lchoose(p, df);
  bic = minus2ln + df*log(n) + tmp;
  return(bic)
}
