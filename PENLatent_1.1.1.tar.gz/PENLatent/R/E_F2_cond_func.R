E_F2_cond_func = function(n, sigma2_Y, Lambda, Beta, E_F, Gamma1){
  
  Var_Fi_cond = (sum(Lambda^2/sigma2_Y) + 1)^(-1) 
  E_F2_cond = rep(NA, n)
  
  for(ii in 1:n){
    E_F2_cond[ii] = Var_Fi_cond + E_F[ii]^2
  }
  return(E_F2_cond)
}
