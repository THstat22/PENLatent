PENLatent <-function(X, D, Y,family=c("gaussian"), penalty=c("Lasso","LOG"), eps=.001,
  NumIter=1000, dfmax=NULL, lambda_vec, tau_vec = 0, NoBetaIndex = 0, depBeta = 1, warmstart = 1)
{
  
  numTuning = length(lambda_vec)
 
  ## Error checking
  family <- match.arg(family)
  penalty <- match.arg(penalty)
  if (numTuning < 2) stop("n.lambdas must be at least 2")

  ## Set up XX, yy, lambda
  n1 <- sum(D)
  p <- ncol(X)
  n <- nrow(X)
  q = L_Lambda = ncol(Y)
  
  if(is.null(dfmax)){
    dfmax = p + 1
  }
  
  #print("test1")
  
  library(psych)
  
  faoutput = fa(r = cor(Y),nfactors=1)
  
  
  
  TuningMatrix = cbind(tau_vec,lambda_vec)
  od = order(TuningMatrix[,1],TuningMatrix[,2],decreasing = TRUE)
  TuningMatrix = TuningMatrix[od,]
  
  if(penalty=="LOG"){
    RestartIndex = rep(c(1,rep(0,(table(tau_vec)[1]-1))),times=length(unique(tau_vec)))
  }else{
    RestartIndex = c(1, rep(0,(nrow(TuningMatrix)-1)))
  }
  
  Dims = rep(0,9)
  Dims[1] = n
  Dims[2] = p
  Dims[3] = q
  Dims[4] = NumIter
  Dims[5] = dfmax
  Dims[6] = numTuning
  Dims[7] = NoBetaIndex
  Dims[8] = depBeta
  Dims[9] = warmstart
  
  Vals = rep(0,3)
  Vals[1] = eps
  Vals[2] = n1
  Vals[3] = n
  
  
  
  
  Iter_vec = rep(0,numTuning)
  Dfvec = rep(0, numTuning)

  SigmaY_output = matrix(0,q, numTuning)
  Lambda_output = matrix(0,q, numTuning)
  for(k in 1:q){
    Lambda_output[k,1] = faoutput$loadings[k,1]
    SigmaY_output[k,1] = faoutput$residual[k,k]
  }
  rm(faoutput)
  #print(Lambda_output[,1])
  
  Gamma1_output = rep(0, numTuning)
  Beta_output = matrix(0, p, numTuning)
  iter_output = rep(0,numTuning)
  minus2ln_output = rep(0,numTuning)
  #print("test2")
  
  fit <- .C("gaussian_model",  as.double(t(Y)), as.double(t(X)), as.double(D), as.double(TuningMatrix[,2]),
            as.double(TuningMatrix[,1]),
            Beta_output=as.double(t(Beta_output)), Gamma1_output = as.double(Gamma1_output),  
            Lambda_output = as.double(t(Lambda_output)), SigmaY_output = as.double(t(SigmaY_output)),
            as.double(Vals), as.integer(Dims), iter_output=as.integer(iter_output), Dfvec=as.integer(Dfvec),
            minus2ln_output = as.double(minus2ln_output), penalty, RestartIndex = as.integer(RestartIndex))

  Lambda_output = matrix(fit$Lambda_output, q, numTuning, byrow=TRUE)
  SigmaY_output = matrix(fit$SigmaY_output, q, numTuning, byrow=TRUE)
  Beta_output = matrix(fit$Beta_output, p, numTuning, byrow=TRUE)
  
  rownames(Beta_output) = colnames(X)

  Gamma1_output = fit$Gamma1_output
  iter_output = fit$iter_output
  Dfvec = fit$Dfvec
  minus2ln_output = fit$minus2ln_output
  
  EBICvec = rep(0,length(minus2ln_output))
  for(ii in 1:length(minus2ln_output)){
    EBICvec[ii] = ExtendedBIC(minus2ln_output[ii],p,Dfvec[ii],n)
  }
  BICvec = rep(0,length(minus2ln_output))
  for(ii in 1:length(minus2ln_output)){
    BICvec[ii] = BIC(minus2ln_output[ii],p,Dfvec[ii],n)
  }
  
  wrm = which(iter_output==0)
  if(length(wrm)>0){
    EBICvec[wrm] = 100000
    BICvec[wrm] = 100000
  }
  output = list()
  output[["iter"]] = iter_output
  output[["Dfvec"]] = Dfvec
  output[["Gamma1"]] = Gamma1_output
  output[["Lambda"]] = Lambda_output
  output[["SigmaY"]] = SigmaY_output
  output[["Beta"]] = Beta_output
  output[["EBICvec"]] = EBICvec
  output[["BICvec"]] = BICvec
  
  return(output)
}
