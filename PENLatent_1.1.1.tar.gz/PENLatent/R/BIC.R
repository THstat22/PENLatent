BIC <-
function(minus2ln,p,df,n){
  bic = minus2ln + df*log(n);
  return(bic)
}
