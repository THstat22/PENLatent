Gamma2_func = function(D, Gamma1, Gamma2_current, Lambda, Beta, Y, sigma2_Y){
  Gamma2 = Gamma2_current
  
  for(k in 1:length(Gamma2)){
    numerator =  sum( D*(Y[,k] - Lambda[k]*( Gamma1 + sum(Gamma2[-k]) )*( 1 + sum(Beta^2))  ))
    denomerator = ( sum( D*(sigma2_Y[k] + Lambda[k]^2*(1 +  sum(Beta^2))  )   )  )
    Gamma2[k] =  numerator/denomerator
  }
  return(Gamma2)
}
