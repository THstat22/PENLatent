Gamma1_func = function(n1, Beta, Lambda, Gamma2, D, F){
  numerator  = sum( D*( F - (1 + sum(Beta^2))*(sum(Lambda*Gamma2)) ) )
  denomerator = n1*(1 + sum(Beta^2))
  Gamma1 = numerator/denomerator
  
  return(Gamma1)
}