/*
 *  utility.c
 *
 *  Created by Ting-Huei Sep 4 2017.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <R.h>
#include <Rmath.h>
#include "utility.h"

static double *vector(int n)
{
  double *v;
  v = Calloc(n, double);
  return v;
}

static void free_vector(double *v)
{
  Free(v);
}

/**********************************************************************
 * 
 * reorg
 *
 * Reorganize a vector to a matrix of given size. 
 *
 * Allocation done by R_alloc, so that R does the cleanup.
 *
 **********************************************************************/

void reorg(double *v, double ***m, int nrow, int ncol)
{
    int i;
    
    *m = (double **)R_alloc(nrow, sizeof(double*));
    
    (*m)[0] = v;
    if(nrow>1){
        for(i=1; i<nrow; i++){
            (*m)[i] = (*m)[i-1] + ncol;
        }
    }
}

void reorg_int(int *v, int ***m, int nrow, int ncol)
{
    int i;
    
    *m = (int **)R_alloc(nrow, sizeof(int*));
    
    (*m)[0] = v;
    if(nrow>1){
        for(i=1; i<nrow; i++){
            (*m)[i] = (*m)[i-1] + ncol;
        }
    }
}


/**********************************************************************
 * 
 * mean
 *
 * calculate the mean value of a vector
 *
 **********************************************************************/
double mean(double *v, int size){
  int i;
  double ave = 0.0;
  for(i=0; i<size; i++){ ave += v[i]; }
  ave /= size;
  return(ave);
}

double mean_j(double **v, int j, int size){
  int i;
  double ave = 0.0;
  for(i=0; i<size; i++){ ave += v[i][j]; }
  ave /= size;
  return(ave);
}

/**********************************************************************
 * 
 * var
 *
 * calculate the variance of a vector
 *
 **********************************************************************/
double var(double *v, int size){
  int i;
  double ave, ave2;
  ave = ave2 = 0.0;
  for(i=0; i<size; i++){ 
    ave += v[i]; 
    ave2 += v[i]*v[i];
  }
  ave /= size;
  ave2 /= size;
  return(ave2 - ave*ave);
}

/**********************************************************************
 * E_F_cond_func, here nf = 1 so Gamma1 is a scalar
 *
 **********************************************************************/

void SigmaY_func(double* SigmaY, double* E_F_cond, double* E_F2_cond, int n, int q, double* Lambda, double** Y){
   int i, k;
   double tmp;
   for(k=0; k<q; k++){
     tmp = 0;
     for(i=0; i<n; i++){
       tmp = tmp + (Y[i][k]*Y[i][k] - 2*Y[i][k]*Lambda[k]*E_F_cond[i] + Lambda[k]*Lambda[k]*E_F2_cond[i]);
     }
     SigmaY[k] = tmp/n;
   }
}


void E_F_cond_func(double* E_F_cond, int n, int q, int p, double* Lambda, double** Y, double** X, 
  double* Gamma1, double* Beta, double* D, double* SigmaY) {
  double sum_Lambda_sq, Var_Fi_cond, tmp_k, tmp_p;
  int i, j, k;
  sum_Lambda_sq = 0;
  for(k=0; k<q; k++){
    sum_Lambda_sq = sum_Lambda_sq + Lambda[k]*Lambda[k]/SigmaY[k];
  }
  Var_Fi_cond = 1/(sum_Lambda_sq + 1);
  
  for(i=0; i<n; i++){
    tmp_k = 0;
    tmp_p = 0;
    
    for(k=0; k<q; k++){
      tmp_k = tmp_k + Y[i][k]*Lambda[k]/SigmaY[k];
    }
    for(j=0; j<p; j++){
      tmp_p = tmp_p + X[i][j]*Beta[j];
    }
    if(D[i]==0){
      E_F_cond[i] = (tmp_k + tmp_p)*Var_Fi_cond;
    }else{
      E_F_cond[i] = (tmp_k + Gamma1[0] + tmp_p)*Var_Fi_cond;
    }
  }
}

/**********************************************************************
 * E_F2_cond_func, here nf = 1 so Gamma1 is a scalar
 *
 **********************************************************************/

void E_F2_cond_func(double* E_F2_cond, double* F, int n, int q, double* Lambda, double* SigmaY) {
  int i, k; 
  double Var_Fi_cond, tmp;
  
  tmp = 0;
  for(k=0; k<q; k++){
    tmp = tmp + Lambda[k]*Lambda[k]/SigmaY[k];
  }
  Var_Fi_cond = 1/(tmp + 1);
  
  for(i=0; i<n; i++){
    E_F2_cond[i] = Var_Fi_cond + F[i]*F[i];
  }
  
}

/**********************************************************************
 * Gamma1_func
 *
 **********************************************************************/

void Gamma1_func(double* Gamma1, double n1, int n, int q, int p, double* Beta, double* D, double* F,
  double* Lambda, int depBeta, double* covX){
  int i, j,j1, k;
  double numerator, denomerator, sum_Beta_sq, tmp;
  double* tmpBetaSigmaBeta;
  
  tmpBetaSigmaBeta = vector(p);
  
  sum_Beta_sq = 0;
  
  if(depBeta==0){
    for(j=0; j<p; j++){
      sum_Beta_sq = sum_Beta_sq + Beta[j]*Beta[j];
    }
  }else{
      
    for(j=0; j<p; j++){
      tmp = 0;
      for(j1=0; j1<p; j1++){
        tmp = tmp + Beta[j1]*covX[(j*p+j1)];
      }
      tmpBetaSigmaBeta[j] = tmp;
    }
    for(j=0; j<p; j++){
      sum_Beta_sq = sum_Beta_sq + tmpBetaSigmaBeta[j]*Beta[j];
    }
  }
  //Rprintf("sum_Beta_sq=%e\n",sum_Beta_sq);

  
  numerator = 0;
  for(i=0; i<n; i++){
    if(D[i]==1){
      numerator = numerator + F[i];
    }
  }
  //Rprintf("numerator=%e\n",numerator);
  //Rprintf("n1=%e\n",n1);


  denomerator = n1*(1 + sum_Beta_sq);
  
  Gamma1[0] = numerator/denomerator;
  
  free_vector(tmpBetaSigmaBeta);
}



/**********************************************************************
 * Lambda_func
 *
 **********************************************************************/
 void Lambda_func(double* Lambda, int n, int q, int p, double n1, double* Gamma1, double* Beta,
   double* F, double* F2, double** Y){
  int i, j, k, k1;
  double tmp_YxF, sum_Beta_sq, numerator, denomerator, sum_F2;
  
  sum_F2 = 0;
  for(i=0; i<n; i++){
    sum_F2 = sum_F2 + F2[i];
  }
  
   for(k=0; k<q; k++){
    
    tmp_YxF = 0;
    for(i=0; i<n; i++){
      tmp_YxF = tmp_YxF + Y[i][k]*F[i];
    }
    
    numerator = tmp_YxF;
    denomerator = sum_F2;
    
    Lambda[k] = numerator/denomerator;
  
  }
  

}
 

/**********************************************************************
 * Beta_func
 *
 **********************************************************************/

double Beta_func(double**X, double* beta, double* sum_FX, double* sum_X_sq, int n, int p, int j,
  double deno_p2, int depBeta, double* covX, double n_d){
    int i, j1;
    double nume, tmp, deno, bhat;
    nume = 0;
    tmp = 0;
    for(j1=0; j1<p; j1++){
      if(j1!=j){
        tmp = tmp + covX[(j*p)+j1]*beta[j1];
      }
    }
    if(depBeta==0){
      nume = tmp*n_d;
    }else{
      nume = tmp*(n_d + deno_p2);
    }
    
    nume = sum_FX[j] - nume;
    if(depBeta==0){
      deno = sum_X_sq[j] + deno_p2;
    }else{
      deno = sum_X_sq[j] + deno_p2*sum_X_sq[j]/n_d;
    }
    bhat = nume/deno;
    return(bhat);

}

/**********************************************************************
 * minus2ln_func
 *
 **********************************************************************/

double minus2ln_func(int n, int q, int p, double* Lambda, double** Y, double** X,
  double* Gamma1, double* Beta, double* D, double* SigmaY, double* covX) {
  double sum_Lambda_sq, Var_Fi_cond, tmp_k, tmp_p, minus2ln_val, tmp_y, twoln_val;
  double ind2like, logsumSigma, tmp, sum_Beta_sq;
  int i, j, k, j1;
  double* tmpBetaSigmaBeta;
    
  tmpBetaSigmaBeta = vector(p);
  sum_Beta_sq = 0;
  for(j=0; j<p; j++){
    tmp = 0;
    for(j1=0; j1<p; j1++){
      tmp = tmp + Beta[j1]*covX[(j*p+j1)];
    }
    tmpBetaSigmaBeta[j] = tmp;
  }
  for(j=0; j<p; j++){
    sum_Beta_sq = sum_Beta_sq + tmpBetaSigmaBeta[j]*Beta[j];
  }
  
  
  sum_Lambda_sq = 0;
  logsumSigma = 0;
  for(k=0; k<q; k++){
    sum_Lambda_sq = sum_Lambda_sq + Lambda[k]*Lambda[k]/SigmaY[k];
    logsumSigma = -1*log(SigmaY[k]);
  }
  
  
  minus2ln_val = 0;
  twoln_val = 0;
  for(i=0; i<n; i++){
    tmp_k = 0;
    tmp_p = 0;
    tmp_y = 0;
    
    for(k=0; k<q; k++){
      tmp_y = tmp_y + Y[i][k]*Y[i][k]/SigmaY[k];
      tmp_k = tmp_k + Y[i][k]*Lambda[k]/SigmaY[k];
    }
    for(j=0; j<p; j++){
      tmp_p = tmp_p + X[i][j]*Beta[j];
    }
    if(D[i]==0){
      ind2like = logsumSigma - tmp_y -(tmp_p*tmp_p) + (tmp_k + tmp_p)*(tmp_k + tmp_p)/(1 + sum_Lambda_sq);
    }else{
      ind2like = logsumSigma - tmp_y -(tmp_p*tmp_p) + (Gamma1[0]+ tmp_k + tmp_p)*(Gamma1[0]+ tmp_k + tmp_p)/(1 + sum_Lambda_sq) - Gamma1[0]*Gamma1[0] - sum_Beta_sq*Gamma1[0]*Gamma1[0];
    }
    twoln_val = twoln_val + (ind2like);
  }
  minus2ln_val = -1*twoln_val;
    
  return(minus2ln_val);
}


/**********************************************************************
 * 
 * rsample
 *
 * generate a permutaion from 0 to n-1 using Knuth shuffle
 * http://en.wikipedia.org/wiki/Knuth_shuffle 
 *
 **********************************************************************/

void rsample(int* per, int n) {
  int i, j, v;
  double rU;
  
  for (i=0; i<n; i++) {
    per[i] = i;
  }
 
  for (i=n-1; i>0; i--) {
    rU = runif(0,1);
    j = floor(rU*(i+1)); /* a integer from 0 to i */
    v = per[i];
    per[i] = per[j];
    per[j] = v;
  }
}

/**********************************************************************
 * 
 * rinvGauss
 *
 * generate random numbers from invers Gaussian distribution
 *
 **********************************************************************/
 
double rinvGauss1(double mu, double lambda){
 	double x1, y, z;
 	y  = rchisq(1);
 	x1 = (mu/(2*lambda))*(2*lambda + mu*y - sqrt(4*lambda*mu*y + mu*mu*y*y));
 	z  = runif(0,1);
 	// Rprintf("y=%f, x1=%f, z=%f\n", y, x1, z);
 	if(z < mu/(mu + x1)){
 		return(x1);
 	}else{
 	  return(mu*mu/x1);
  }
}

void rinvGauss(double *x, int* nR, double* mu, double* lambda){
  int i, n;
  n = *nR;
  
  GetRNGstate();

  for(i=0; i < n; i++){
    x[i] = rinvGauss1(*mu, *lambda);
  }
  PutRNGstate();
}

/**********************************************************************
 * 
 * dinvGauss
 *
 * density function for invers Gaussian distribution
 *
 **********************************************************************/
 
void dinvGauss(double* y, double* x, int* n, double* Rmu, double* Rlambda){
  int i;
  double mu, lambda;
  mu = *Rmu;
  lambda = *Rlambda;
  
  for(i=0; i<*n; i++){
  	y[i] = exp(-lambda*(x[i] - mu)*(x[i] - mu)/(2*mu*mu*x[i]));
  	y[i] *= sqrt(lambda/6.283187)*pow(x[i], -1.5);
  }
}


/**********************************************************************
 *
 * readtext (double**, char*, int, int, int, int, int) 
 * 
 * Read the data from the text file
 * The text file must be separated by "whitespace" 
 * The number of rows and columns have to be provided.
 * The element cannot be empty
 * The elements are checked to see whether it is numerical or not
 * Each elements has the maximum 255 characters
 **********************************************************************/

void readtext(double **matrix, char *str, int nrows, int ncols, 
  int offsetrow, int offsetcol, int transpose)
{
  FILE *file;
  int i,j;
  char temp[255];
  file = fopen(str,"r+t");
  if(file == NULL){
    error("fail to open file %s\n", str);
  }
  Rprintf("start reading file\n");
  
  if (transpose==0) {
    for (i=-offsetrow; i<nrows; i++) {
      for (j=-offsetcol; j<ncols; j++) {
        fscanf(file,"%s",temp);
        if(i>=0 && j>=0){
          matrix[i][j] = atof(temp);
        }
      }
    }
  } else {
    // Need to transpose the matrix when loading the file.
    for (j=-offsetcol; j<ncols; j++) {
      for (i=-offsetrow; i<nrows; i++) {
        fscanf(file,"%s",temp);
        if(i>=0 && j>=0){
          matrix[i][j] = atof(temp);
        }
      }
    }
  }
  fclose(file);
}


/**********************************************************************
 *
 * determinant (double** A, int n, double* det) 
 *
 * clacluate the determinant of square matrix A by LU decomposition
 * n is the dimension of the matrix, and det is the determinant
 **********************************************************************/

void determinant(double** A, int n, double* det){
  
  int i, j, k, kb, imax, s1, s2;
  double tmp, pivot;

  /**
   * use det to record the number of row exchange. 
   * det = 1.0 if there are even number of exchagnes and 
   * det = -1.0 if there are odd number of exchanges.
   */
  *det = 1.0;
    
  for(j=0; j<n; j++){
  
    pivot = 0.0;
    imax  = j;
    
    for(i=0; i<n; i++){
      tmp = A[i][j];
      kb  = i; if(i >= j) kb = j;
      for(k=0; k<kb; k++) tmp -= A[i][k]*A[k][j];
      A[i][j] = tmp;
      
      /**
       * If i >= j, consider to exchange rows from here. 
       */
      if(i>=j){
        tmp = fabs(tmp);
        if(tmp >= pivot){ pivot = tmp; imax  = i; }
      }
    }
    
    /**
     * if the pivot is not the current diagnal one, exchange rows
     * well, one easier way is to exchange row ponters
     * however, this will chagne the matrix A in the upper level function
     * if A[0] is switched to somewhere else, it may cause problem
     * when you free the matrix
     */
    if(imax != j){
      for(k=0; k<n; k++){
        tmp = A[j][k];
        A[j][k] = A[imax][k];
        A[imax][k] = tmp;
      }
      (*det)  = -(*det);
    }
    
    if(fabs(A[j][j]) < 1e-16){
      Rprintf("j=%d\n", j);
      for(s1=0; s1<n; s1++){
        for(s2=0; s2<n; s2++){
          printf("%f ", A[s1][s2]);
        }
        printf("\n");
      }
      error("singular matrix in determinant calculation\n");
    }
    
    tmp = A[j][j];
    for(i=j+1; i<n; i++) A[i][j] /= tmp;
  }
  
  for(j=0; j<n; j++) (*det) *= A[j][j];
}

void detR(double* RA, int* n, double* det){
  double **A;
  reorg(RA, &A, *n, *n);
  determinant(A, *n, det);
}

/**********************************************************************
 * 
 * print_v
 *
 * print out a vector of type double
 *
 **********************************************************************/

void print_v(double* v, int nrl, int nrh)
{
	int i;
	for (i = nrl; i < nrh; i++){
		printf ("%f\t", v[i]);
	}
	printf ("%f\n", v[i]);
}

void Rprint_v(double* v, int nrl, int nrh)
{
	int i;
	for (i = nrl; i < nrh; i++){
		Rprintf ("%f\t", v[i]);
	}
	Rprintf ("%f\n", v[i]);
}

void Rprint_ve(double* v, int nrl, int nrh)
{
	int i;
	for (i = nrl; i < nrh; i++){
		Rprintf ("%.2e\t", v[i]);
	}
	Rprintf ("%.2e\n", v[i]);
}

void Rprint_vi(int* v, int nrl, int nrh)
{
	int i;
	for (i = nrl; i < nrh; i++){
		Rprintf ("%d\t", v[i]);
	}
	Rprintf ("%d\n", v[i]);
}

/**********************************************************************
 * 
 * print_me
 *
 * print out a matrix of format %e
 *
 **********************************************************************/

void print_me(double** m, long nrl, long nrh, long ncl, long nch)
{
	int i, j;
	for (i = nrl; i <= nrh; i++){
    for(j = ncl; j <= nch; j++){
      printf ("%.2e\t", m[i][j]);
    }
    printf("\n");
	}
}

void Rprint_me(double** m, long nrl, long nrh, long ncl, long nch)
{
	int i, j;
	for (i = nrl; i <= nrh; i++){
    for(j = ncl; j <= nch; j++){
      Rprintf ("%.2e\t", m[i][j]);
    }
    Rprintf("\n");
	}
}

void Rprint_mi(int** m, long nrl, long nrh, long ncl, long nch)
{
	int i, j;
	for (i = nrl; i <= nrh; i++){
    for(j = ncl; j <= nch; j++){
      Rprintf ("%i\t", m[i][j]);
    }
    Rprintf("\n");
	}
}

/**********************************************************************
 * 
 * print_mf
 *
 * print out a matrix of format %f
 *
 **********************************************************************/

void print_mf(double** m, long nrl, long nrh, long ncl, long nch)
{
	int i, j;
	for (i = nrl; i <= nrh; i++){
    for(j = ncl; j <= nch; j++){
      printf ("%f\t", m[i][j]);
    }
    printf("\n");
	}
}

void Rprint_mf(double** m, long nrl, long nrh, long ncl, long nch)
{
	int i, j;
	for (i = nrl; i <= nrh; i++){
    for(j = ncl; j <= nch; j++){
      Rprintf ("%f\t", m[i][j]);
    }
    Rprintf("\n");
	}
}

