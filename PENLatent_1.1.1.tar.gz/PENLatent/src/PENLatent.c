#include <math.h>
#include <string.h>
#include "Rinternals.h"
#include "R_ext/Rdynload.h"
#include <R.h>
#include "utility.h"
#include <R_ext/Applic.h>

static double *vector(int n)
{
  double *v;
  v = Calloc(n, double);
  return v;
}

static void free_vector(double *v)
{
  Free(v);
}

static int checkConvergence(double *beta, double *beta_old,
                            double eps, int J)
{
  int j;
  int converged = 1;
  for (j=0; j < J; j++)
    {
      if (beta[j]!=0 & beta_old[j]!=0)
	{
	  if (fabs((beta[j]-beta_old[j])/beta_old[j]) > eps)
	    {
	      converged = 0;
	      break;
	    }
	}
      else if (beta[j]==0 & beta_old[j]!=0)
	{
	  converged = 0;
	  break;
	}
      else if (beta[j]!=0 & beta_old[j]==0)
	{
	  converged = 0;
	  break;
	}
    }
  return(converged);
}


static double S(double z, double l)
{
  if (z > l)  return(z - l);
  if (z < -l) return(z + l);
  return(0);
}




static double Lasso(double z, double l1)
{
  double s=0;
  
  if (z > 0) s = 1;
  else if (z < 0) s = -1;
    
  if (fabs(z) <= l1) return(0);
  else return(s*(fabs(z)-l1));
}



static double LOGlm(double z, double lambda, double tau, double bhat,
                    double v, int Index)
{
  double s=0;
  double threshold;
  
  if (Index==1) {
    threshold = ((lambda)/(fabs(bhat) + tau));
    if (z > 0) s = 1;
    else if (z < 0) s = -1;
    
    if (fabs(z) <= threshold/v) return(0);
    else return(z - s*threshold/v );
  }else{
    return(z);
  }
}









static void gaussian_model(double *RY, double *RX, double *D, double *lambda_vec, 
            double *tau_vec,
            double *RBeta_output, double* Gamma1_output,  double* RLambda_output, double* RSigmaY_output,
            double *Vals, int *Dims, int* iter_output, int* Dfvec, double *minus2ln_output, char **penalty_ , int* RestartIndex)
{
  /* Declarations */
  double **X, **Y, **Beta_output, **Lambda_output, **SigmaY_output;
  int n = Dims[0], p = Dims[1], q = Dims[2], NumIter = Dims[3], dfMax = Dims[4], numTuning = Dims[5], NoBetaIndex = Dims[6], depBeta= Dims[7], warmstart = Dims[8];
  double eps = Vals[0], n1 = Vals[1], n_d = Vals[2], Plambda, Ptau;
  char *penalty=penalty_[0];
  
  
  //Rprintf("ctest0");
  reorg(RX, &X, n, p);
  //Rprintf("ctest01");

  reorg(RY, &Y, n, q);
  //Rprintf("ctest02");

  reorg(RBeta_output, &Beta_output, p, numTuning);
  //Rprintf("ctest03");

  reorg(RLambda_output, &Lambda_output, q, numTuning);
  //Rprintf("ctest4");
  reorg(RSigmaY_output, &SigmaY_output, q, numTuning);



  int converged, active, i, l, j, k, j1, tuningI, BreakIndex;
  double tmp, tmp1, deno, deno_p2, nume, bhat;
  double *sum_X_sq, *sum_FX;
  double *Lambda_old, *Lambda, *Lambda_init, *SigmaY_init, *SigmaY, *SigmaY_old;
  double *Gamma1_old, *Gamma1;
  double *E_F, *E_F2, *beta, *beta_old, *covX;
  
  
  Lambda = vector(q);
  Lambda_init = vector(q);
  SigmaY_init  = vector(q);
  SigmaY = vector(q);
  SigmaY_old = vector(q);
  Lambda_old = vector(q);
  Gamma1_old = vector(1);
  Gamma1 = vector(1);
  covX = vector(p*p);
  
  //Rprintf("ctest1");
  for (j=0; j<p; j++){
    for (j1=0; j1<p; j1++){
      tmp = 0;
      for(i=0; i<n; i++){
        tmp = tmp + X[i][j]*X[i][j1];
      }
      covX[j*p+j1] = tmp/n_d;
    }
  }
  //Rprintf("covX[0]=%e\n",covX[0]);
  //Rprintf("covX[200]=%e\n",covX[200]);
  //Rprintf("covX[305]=%e\n",covX[305]);
  //Rprintf("covX[1000]=%e\n",covX[1000]);
  //Rprintf("covX[1299]=%e\n",covX[1299]);
  
  
  for(k=0; k<q; k++){
    Lambda_init[k] = Lambda_output[k][0];
    SigmaY_init[k] = SigmaY_output[k][0];
  }
  
  E_F = vector(n);
  E_F2 = vector(n);
  
  for(i=0; i<n; i++){
    E_F[i] = 0;
    E_F2[i] = 0; 
  }
  
  
  beta = vector(p);
  beta_old = vector(p);
  
  
  sum_X_sq = vector(p);
  sum_FX = vector(p);
  
  for (j=0; j<p; j++){
    tmp = 0;
    for(i=0; i<n; i++){
      tmp = tmp + X[i][j]*X[i][j];
    }
    
    beta_old[j] = 0;
    beta[j] = 0;

    sum_X_sq[j] = tmp;
    sum_FX[j] = 0;
  }
  //Rprintf("sum_X_sq[0]=%e\n",sum_X_sq[0]);
  //Rprintf("sum_FX=[0]=%e\n", sum_FX[0]);


  for(tuningI=0; tuningI<numTuning; tuningI++){
    
    Plambda = lambda_vec[tuningI];
    
    if (strcmp(penalty,"LOG")==0){
      Ptau = tau_vec[tuningI];
    }

    if(warmstart==1){
      if(RestartIndex[tuningI]==1){
        for(k=0; k<q; k++){
          Lambda[k] = Lambda_init[k];
          Lambda_old[k] = 0;
          SigmaY_old[k] = 0;
          SigmaY[k] = SigmaY_init[k];
        }
        Gamma1[0] = 0;
        Gamma1_old[0] = 0;
        for (j=0; j<p; j++){
          beta_old[j] = 0;
          beta[j] = 0;
        }
      }
    }else{
      for(k=0; k<q; k++){
        Lambda[k] = Lambda_init[k];
        Lambda_old[k] = 0;
        SigmaY_old[k] = 0;
        SigmaY[k] = SigmaY_init[k];
      }
      Gamma1[0] = 0;
      Gamma1_old[0] = 0;
      for (j=0; j<p; j++){
        beta_old[j] = 0;
        beta[j] = 0;
      }
    }
    
    E_F_cond_func(E_F, n, q, p, Lambda, Y, X, Gamma1, beta,D, SigmaY);
    E_F2_cond_func(E_F2, E_F, n, q, Lambda, SigmaY);
    Gamma1_func(Gamma1, n1, n, q, p, beta, D, E_F, Lambda, depBeta, covX);
    Lambda_func(Lambda, n, q, p, n1, Gamma1, beta, E_F, E_F2, Y);
    SigmaY_func(SigmaY, E_F, E_F2, n, q, Lambda, Y);
    
    //Rprintf("E_F[0]=%e\n",E_F[0]);
    //Rprintf("E_F2[0]=%e\n",E_F2[0]);
    //Rprintf("Gamma1[0]=%e\n",Gamma1[0]);
    //Rprintf("Lambda[0]=%e\n",Lambda[0]);

    //Rprintf("E_F[2]=%e\n",E_F[2]);
    //Rprintf("E_F2[2]=%e\n",E_F2[2]);
    //Rprintf("Lambda[2]=%e\n",Lambda[2]);


   
  
    deno_p2 = (n1)*pow(Gamma1[0],2);
    
    for (j=0; j<p; j++){
      tmp1 = 0;
    
      for(i=0; i<n; i++){
        tmp1 = tmp1 + E_F[i]*X[i][j];
      }
    
      sum_FX[j] = tmp1;
    }
    
    
    //Rprintf("sum_FX[0]=%e\n",sum_FX[0]);

    BreakIndex = 0;
    for (l=0; l<NumIter; l++){
    
    if(NoBetaIndex!=1){
      for (j=0; j<p; j++){
        
        bhat = Beta_func(X, beta, sum_FX, sum_X_sq, n, p,j, deno_p2, depBeta, covX, n_d);
        
        if (strcmp(penalty,"Lasso")==0){
          beta[j] = Lasso(bhat, Plambda);
        } 
        if (strcmp(penalty,"LOG")==0){
          beta[j] = LOGlm(bhat,Plambda,Ptau, beta_old[j],n,1);
        } 

      }
      //Rprintf("beta[10]=%e\n",beta[10]);
      //Rprintf("beta[0]=%e\n",beta[0]);
    }
      
      E_F_cond_func(E_F, n, q, p, Lambda, Y, X, Gamma1, beta,D, SigmaY);
      E_F2_cond_func(E_F2, E_F, n, q, Lambda, SigmaY);
      Gamma1_func(Gamma1, n1, n, q, p, beta, D, E_F, Lambda, depBeta, covX);
      Lambda_func(Lambda, n, q, p, n1, Gamma1, beta, E_F, E_F2, Y);
      SigmaY_func(SigmaY, E_F, E_F2, n, q, Lambda, Y);

      
      //Rprintf("E_F[0]=%e\n",E_F[0]);
      //Rprintf("E_F2[0]=%e\n",E_F2[0]);
      //Rprintf("Gamma1[0]=%e\n",Gamma1[0]);
      //Rprintf("Lambda[0]=%e\n",Lambda[0]);

      //Rprintf("E_F[2]=%e\n",E_F[2]);
      //Rprintf("E_F2[2]=%e\n",E_F2[2]);
      //Rprintf("Lambda[2]=%e\n",Lambda[2]);


    
      converged = 0;

      /* Check dfMax */
      active = 0;
      for (j=0; j<p; j++){
        if (beta[j]!=0) active++;
      
        if (active > dfMax){
          Dfvec[tuningI] = active;
          BreakIndex = 1;
          break;
        }
      }
      if(BreakIndex == 1){break;}
      
      //Rprintf("active=%d\n",active);
      /* Check for convergence */
    
      if (checkConvergence(beta, beta_old, eps, p)){
        if (checkConvergence(Lambda, Lambda_old, eps, q)){
          if (checkConvergence(SigmaY, SigmaY_old, eps, q)){
            if (fabs(Gamma1[0]-Gamma1_old[0]) < eps){
              converged  = 1;
               
              for (j=0; j<p; j++){
                Beta_output[j][tuningI] = beta[j];
              }
               
              for(k=0; k<q; k++){
                Lambda_output[k][tuningI] = Lambda[k];
                SigmaY_output[k][tuningI] = SigmaY[k];
              }
              Gamma1_output[tuningI] = Gamma1[0];
               
              Dfvec[tuningI] = active;
              iter_output[tuningI] = l;
              minus2ln_output[tuningI] = minus2ln_func(n, q, p, Lambda, Y, X, Gamma1, beta, D, SigmaY, covX);
              break;
            }
          }
        }
      }
    
      
      for (j=0;j<p;j++){
        beta_old[j] = beta[j];
      }
      for(k=0; k<q; k++){
        Lambda_old[k] = Lambda[k];
        SigmaY_old[k] = SigmaY[k];
      }
      Gamma1_old[0] = Gamma1[0];
    }
  }
  
  free_vector(beta);
  free_vector(beta_old);
  free_vector(Lambda);
  free_vector(Lambda_old);
  free_vector(E_F);
  free_vector(E_F2);
  free_vector(sum_FX);
  free_vector(sum_X_sq);
    
}


static const R_CMethodDef cMethods[] = {
  {"gaussian_model", (DL_FUNC) &gaussian_model, 16},
  NULL
};

void R_init_PENLatent(DllInfo *info)
{
  R_registerRoutines(info, cMethods, NULL, NULL, NULL);
}

