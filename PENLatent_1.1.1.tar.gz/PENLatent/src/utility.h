
void reorg(double *v, double ***m, int nrow, int ncol);
void reorg_int(int *v, int ***m, int nrow, int ncol);
double mean(double *v, int size);
double mean_j(double **v, int j, int size);
double var(double *v, int size);
void rsample(int* per, int n);
double rinvGauss1(double mu, double lambda);
void rinvGauss(double *x, int* n, double* mu, double* lambda);
void dinvGauss(double* y, double* x, int* n, double* Rmu, double* Rlambda);
void readtext(double **matrix, char *str, int nrows, int ncols, int offsetrow, int offsetcol, int transpose);
void determinant(double** A, int n, double* det);
void detR(double* RA, int* n, double* det);

void print_v(double* v, int nrl, int nrh);
void Rprint_v(double* v, int nrl, int nrh);
void Rprint_ve(double* v, int nrl, int nrh);
void Rprint_vi(int* v, int nrl, int nrh);

void print_me(double** m, long nrl, long nrh, long ncl, long nch);
void Rprint_me(double** m, long nrl, long nrh, long ncl, long nch);
void Rprint_mi(int** m, long nrl, long nrh, long ncl, long nch);

void print_mf(double** m, long nrl, long nrh, long ncl, long nch);
void Rprint_mf(double** m, long nrl, long nrh, long ncl, long nch);

void SigmaY_func(double* SigmaY, double* E_F_cond, double* E_F2_cond, int n, int q, double* Lambda, double** Y);
void E_F_cond_func(double* E_F_cond, int n, int q, int p, double* Lambda, double** Y, double** X, 
  double* Gamma1, double* Beta, double* D, double* SigmaY);
  
void E_F2_cond_func(double* E_F2_cond, double* F, int n, int q, double* Lambda, double* SigmaY);

void Gamma1_func(double* Gamma1, double n1, int n, int q, int p, double* Beta, double* D, double* F, double* Lambda, int depBeta, double* covX);


void Lambda_func(double* Lambda,int n, int q, int p, double n1, double* Gamma1, double* Beta,
   double* F, double* F2, double** Y);


double Beta_func(double**X, double* beta, double* sum_FX, double* sum_X_sq, int n, int p, int j,
  double deno_p2, int depBeta, double* covX, double n_d);

double minus2ln_func(int n, int q, int p, double* Lambda, double** Y, double** X,
                     double* Gamma1, double* Beta, double* D, double* SigmaY, double* covX);
